<div>
    <p>
    The Vanguard Assurance Workmen’s Compensation policy is designed to help Employers fulfill their legal responsibility towards the Workmen’s Act 1987.
    which makes it compulsory for any Employers of labour to set aside funds to compensate any worker who may sustain injury at the work place whether or not the Employer is to blame.
    </p>
    <p>
    Besides, compensation for injury, Death etc, there is provision for payment of Medical Expenses as a result of the injury an injury sustained whilst in the cause of employment.
    An employer may choose to insure his liability under the Act and in addition can extend his liability to cover medical expenses. Talk to Vanguard Assurance today, to get your legal liabilities towards your employees insured. An enhanced policy is the Vanguard Group Personal Accident policy.
    </p>
</div>