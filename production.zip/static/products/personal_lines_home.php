
Vanguard homeowner’s policy is designed to cover loss or damage to your private dwelling, household goods and personal effects resulting from fire and allied perils or theft. Our policy also covers your liability to third parties for injury or damage sustained at the premises following negligence on your part.
