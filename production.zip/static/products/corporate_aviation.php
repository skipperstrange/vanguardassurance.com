
            <strong>
                The aviation sector in Ghana has been growing rapidly in the past 10 years and so have the liabilities and assets of our cherished industry players.
            </strong>
        <br />
            With the increased values at risk and the complex nature of aviation operations, some players end up employing aircraft insured outside the country for their local operations, despite the legal implications.
   
            At Vanguard Assurance, we strive to ensure that we adequately support the requirements of our clients in the aviation industry by providing them with a range of insurances that meet the varing needs of their various crafts from light aircrafts, helicopters to niche aircrafts. Our Aviation insurances provides coverage for:
                <ol class="text-2">
                    <li>Hull and Engine</li>
                    <li>Spares</li>
                    <li>Liability for passenger injuries,</li>
                    <li>Environmental damage caused by aircraft and</li>
                    <li>Third-party damage caused by aircraft accidents.</li>
                </ol>
      
   