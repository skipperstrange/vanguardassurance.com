<?php


$data['awards'] = [
    [
        'body'=> 'Ghana Accountancy and Finance Awards',
        'title'=> 'Best Insurer in Claims Payment',
        'year' => '2022',
    ],
    [
        'body'=> 'Ghana Premier Business and Finance Excellence Awards',
        'title'=> 'Gold Award Outstanding contribution to Ghana Economic Development',
        'year' => '2022',
    ],
    [
        'body'=> 'Ghana Premier Business Excellence Awards',
        'title'=> 'Outstanding General Insurance Company of the year',
        'year' => '2022',
    ],
    [
        'body'=> 'CIMG',
        'title'=> 'Hall of Fame (10th time) insurance company of the year',
        'year' => '2021',
    ],
    [
        'body'=> 'Ghana Business Standard Awards',
        'title'=> 'Oustanding insurance brand of the year',
        'year' => '2021',
    ],
    [
        'body'=> 'West Africa Business Excellence Awards',
        'title'=> 'Best insurance company of the year',
        'year' => '2020',
    ],
    [
        'body'=> 'Ghana Accountancy and Finance Awards',
        'title'=> 'Claims initiative of the yea',
        'year' => '2018',
    ],
    [
        'body'=> 'Ghana Business Awards',
        'title'=> 'General insurance company of the year',
        'year' => '2018',
    ],
    [
        'body'=> '',
        'title'=> 'Premium Quality insurance company of the year',
        'year' => '2017',
    ],
    [
        'body'=> 'CIMG',
        'title'=> 'Hall of Fame (5th time) insurance company of the year',
        'year' => '2017',
    ],
    [
        'body'=> 'CIMG',
        'title'=> 'Hall of Fame (5th time) insurance company of the year',
        'year' => '2016',
    ],
    [
        'body'=> 'GIBA',
        'title'=> 'Most Broker friendly & Supportive insurer',
        'year' => '2016',
    ],
    [
        'body'=> 'AGI',
        'title'=> 'Best financial services company (Insurance)',
        'year' => '2015',
    ]
];