<?php
 $data['affiliates'] = [
    [
        'name'=>'calbank',
        'title' => 'Calbank',
        'logo'=>'calbank.png'
    ],
    [
        'name'=>'juabeng_rual_bank',
        'title'=>'Juaben Rural Bank',
        'logo' =>'jrb-logo.png',
    ],
    [
        'name'=>'vanguard_life',
        'title'=>'Vanguard Life Assurance Company Limited',
        'logo' => 'vaclife.png',
    ],
   /* 
   [
        'name'=>'ghana_leasing_company',
        'title'=>'Ghana Leasing Company',
        'logo' =>''
    ],
    */
    [
        'name'=>'blue_orchard',
        'title'=>'Blue Orchard',
        'logo' =>'blue-orchard.png'
    ]
];