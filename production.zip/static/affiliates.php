<?php
 $data['affiliates'] = [
    [
        'name'=>'calbank',
        'title' => 'Calbank',
        'logo'=>'calbank.png'
    ],
    [
        'name'=>'juabeng_rual_bank',
        'title'=>'Juaben Rural Bank',
        'logo' =>'jrb-logo.png',
    ],
    [
        'name'=>'vanguard_life',
        'title'=>'Vanguard Life Assurance Company Limited',
        'logo' => 'vaclife.png',
    ],
    [
        'name'=>'munich_re',
        'title'=>'Munich RE',
        'logo' =>'munichRe.png'
    ],
    [
        'name'=>'swissh_re',
        'title'=>'Swissh RE',
        'logo' =>'swissRe.png'
    ],
    [
        'name'=>'blue_orchard',
        'title'=>'Blue Orchard',
        'logo' =>'blue-orchard.png'
    ]
];