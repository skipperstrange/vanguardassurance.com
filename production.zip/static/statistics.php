<?php

$data['stats'] = [
    [
        'title' => 'paid_claims',
        'desc' => 'Paid claims since 2015',
        'value' => '400000',
    ]
]