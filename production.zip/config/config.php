<?php

define('APP_NAME', 'Vanguard Assurance');
define('MODE', 'production');
define('MAINENANCE', false);
define('MVC_MODE', 'strict');
define('PRETTY_URLS', true);