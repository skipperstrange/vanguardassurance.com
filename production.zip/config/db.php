<?php
define('DB_HOST', 'localhost');
define('DB_PORT', '');
define('DB_NAME', '');
define('DB_USER','root');
define('DB_PASSWORD', '');
define('DB_CHARSET', 'utf8');
define('DB_COLLATION', 'utf8_unicode_ci');
define('DB_PREFIX', 'utf8_unicode_ci');
