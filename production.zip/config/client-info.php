<?php

define('CLIENT_NAME', 'Vanguard Assurance Company LTD');
define('WEBSITE', 'https://www.vanguardassurance.com');
define('ADDRESS', '');
define('STREET_ADDRESS', '25 Independence Avenue, Ridge-Accra');
define('SLOGAN', '');
define('SUPPORT_EMAIL', 'vacmails@vanguardassurance.com');
define('SUPPORT_CONTACT_1', '+233 244 334 407');
define('SUPPORT_CONTACT_1_CLEAN', '233244334407');
define('WHATSAPP_CONTACT_1_CLEAN', '233242426444');
define('SUPPORT_CONTACT_2', '+233 302 213 940');

//SOCIAL MEDIA
define('TWITTER', 'https://twitter.com/VanguardGH');
define('FACEBOOK', 'https://www.facebook.com/VanguardGH/');
define('INSTAGRAM', 'https://instagram.com/vanguardgh');
define('LINKEDIN', 'https://linkedin.com/in/vanguard-assurance-902a5051');


//Google 
define('LON', '-0.1952778');
define('LAT', '5.5636111');
define('GOOGLE_MAPS_API_KEY', 'AIzaSyCa_kMyTsMkHPPfjekZj3ywpqJAHQCv1QA');
define('GOOGLE_ANALYITICS_ID', '');

//Apps mobile
define('PLAYSTORE_LINK', 'https://play.google.com/store/apps/details?id=com.vanguard.app');
define('APP_STORE_LINK', 'https://apps.apple.com/gh/app/vanguard-assurance/id1547086101');




