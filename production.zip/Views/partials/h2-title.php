
<div class="row">
    <div class="col text-center">
    <h2 class="text-color-dark font-weight-medium text-8 mb-5 appear-animation animated fadeInRightShorterPlus appear-animation-visible" data-appear-animation="fadeInRightShorterPlus" data-appear-animation-delay="100" style="animation-delay: 100ms;">
    <?= $h2headerTitle;  ?>
    </h2>
    </div>
</div>