<svg class="position-absolute bottom-0 right-0" width="440" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 434.95 228.97" data-appear-animation-svg="true">
<path class="appear-animation animated customLines1anim appear-animation-visible" data-appear-animation="customLines1anim" data-appear-animation-delay="100" data-appear-animation-duration="7s" fill="none" stroke="#2c70b9" stroke-width="2px" stroke-miterlimit="10" d="M0,228.97c0.37-4.22,1.28-10.15,3.69-16.85c5.72-15.86,16-25.23,22.47-30.98
    c21.47-19.1,45.53-24.02,55.15-25.87c12.32-2.37,22.4-2.03,42.55-1.36c30.99,1.03,35.79,4.41,65.02,5.79
    c25.3,1.19,38.83,1.83,57.19-2.38c12.11-2.77,32.93-7.79,52.09-24.17c9.08-7.76,15.13-16.75,27.23-34.72
    c18.15-26.95,15.6-29.8,28.26-46.3c8.43-10.99,21.89-28.15,45.28-39.83c14.25-7.11,27.33-9.77,36.02-10.89" style="animation-duration: 7s; animation-delay: 100ms;"></path>
<path class="appear-animation animated customLines1anim appear-animation-visible" data-appear-animation="customLines1anim" data-appear-animation-delay="100" data-appear-animation-duration="7s" fill="none" stroke="#2c70b9" stroke-width="2px" stroke-miterlimit="10" d="M27.74,228.97c0.41-3.95,1.34-9.32,3.57-15.36c0.63-1.71,3.32-8.75,9.06-16.47c9.23-12.4,20.66-18.9,27.32-22.6
    c19.6-10.89,37.73-12.84,47.49-13.79c7.46-0.73,13.19-0.57,24.64-0.26c20.87,0.57,30.2,2.44,51.06,4.34
    c24.68,2.25,37.03,3.38,49.79,2.3c13.83-1.17,31.1-2.64,49.28-12.89c14.68-8.28,22.96-18.36,32.43-29.87
    c16.91-20.57,14.83-26.82,36.13-55.91c13.41-18.32,21.15-25.28,27.32-30c13.01-9.95,25.17-14.6,29.74-16.21
    c7.6-2.68,14.32-4.08,19.38-4.85" style="animation-duration: 7s; animation-delay: 100ms;"></path>
<path class="appear-animation animated customLines1anim appear-animation-visible" data-appear-animation="customLines1anim" data-appear-animation-delay="100" data-appear-animation-duration="7s" fill="none" stroke="#2c70b9" stroke-width="2px" stroke-miterlimit="10" d="M434.95,33.23c-3.76,0.62-8.89,1.71-14.78,3.7c-4.78,1.62-15.65,5.72-27.32,14.55
    c-9.96,7.54-15.92,15.05-20.43,20.81c-4.46,5.7-5.3,7.71-16.47,25.66c-8.17,13.13-12.25,19.69-15.06,23.74
    c-10.15,14.61-15.76,22.7-26.04,30.77c-11.36,8.91-22.19,12.91-27.83,14.94c-12.97,4.67-23.62,5.67-31.79,6.38
    c-5.3,0.46-12.57,0.82-28.72-0.13c-21.65-1.27-25.84-2.93-44.3-4.47c-18.49-1.54-32.11-2.68-50.04-0.38
    c-11.6,1.48-23.82,3.16-38.04,10.34c-15.41,7.78-23.95,17.38-26.81,20.81c-8.59,10.28-11.03,18.84-11.62,21.06
    c-0.85,3.22-1.23,5.99-1.4,7.95" style="animation-duration: 7s; animation-delay: 100ms;"></path>
<path class="appear-animation animated customLines1anim appear-animation-visible" data-appear-animation="customLines1anim" data-appear-animation-delay="100" data-appear-animation-duration="7s" fill="none" stroke="#2c70b9" stroke-width="2px" stroke-miterlimit="10" d="M81.23,228.97c0.33-1.82,0.89-4.38,1.91-7.32c0.69-1.99,3.53-9.75,11.49-18.51
    c10.15-11.17,22.07-16.76,27.83-19.4c3.41-1.56,17.97-8,38.43-9.19c4.78-0.28,10.29,0.03,21.32,0.64
    c15.67,0.87,22.56,1.84,39.57,3.32c20.62,1.8,30.93,2.7,38.68,2.43c12.05-0.42,23.29-0.81,37.15-5.74
    c8.39-2.99,22.75-9.42,35.87-22.6c4.96-4.98,9.47-11.79,18.51-25.4c13.63-20.55,13.63-23.26,23.11-36.13
    c9.58-13.02,15.08-20.34,25.15-27.19c11.13-7.57,23.32-11.47,25.4-12.13c3.74-1.17,6.95-1.93,9.29-2.43" style="animation-duration: 7s; animation-delay: 100ms;"></path>
<path class="appear-animation animated customLines1anim appear-animation-visible" data-appear-animation="customLines1anim" data-appear-animation-delay="100" data-appear-animation-duration="7s" fill="none" stroke="#2c70b9" stroke-width="2px" stroke-miterlimit="10" d="M434.95,65.65c-2.69,0.4-6.36,1.13-10.57,2.55c-8.82,2.99-14.68,7.25-19.02,10.47
    c-2.74,2.03-10.19,7.78-18.38,18c-4.1,5.12-4.47,6.46-13.79,21.45c-8.32,13.38-12.48,20.07-18.13,27.83
    c-7.95,10.93-11.92,16.39-17.36,21.06c-13.02,11.18-27.01,14.91-35.11,16.98c-10.65,2.72-18.65,2.94-30.26,3.19
    c-10.74,0.23-15.84-0.44-47.87-3.32c-27.06-2.44-30.83-2.62-36.89-2.43c-12.79,0.42-23.32,0.86-36.13,5.74
    c-6.61,2.52-19.65,7.67-30.77,20.68c-6.72,7.86-10.31,15.76-12.26,21.1" style="animation-duration: 7s; animation-delay: 100ms;"></path>
</svg>