<svg width="390" class="custom-svg-position-3 opacity-6" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 393.91 241.97" data-appear-animation-svg="true">
						<path class="appear-animation animated customLines1anim appear-animation-visible" data-appear-animation="customLines1anim" data-appear-animation-delay="100" data-appear-animation-duration="7s" fill="none" stroke="#2c70b9" stroke-width="2px" stroke-miterlimit="10" d="M319.44,0c0.95,3.34,2,7.87,2.55,13.31c0.3,2.94,1.03,10.65-0.51,19.4c-3.52,20.06-16.69,32.75-19.66,35.49
							c-5.75,5.3-10.67,7.86-19.15,12.26c-16.63,8.63-31.03,11.66-37.28,12.77c-10.68,1.89-18.28,1.79-28.09,1.79
							c-21.27-0.01-46.27-0.02-63.83,1.28c-25.63,1.89-43.02,3.18-63.06,13.53c-23.42,12.1-38.73,30.52-45.7,39.06
							c-6.79,8.32-11.7,15.96-15.06,21.7" style="animation-duration: 7s; animation-delay: 100ms;"></path>
						<path class="appear-animation animated customLines1anim appear-animation-visible" data-appear-animation="customLines1anim" data-appear-animation-delay="100" data-appear-animation-duration="7s" fill="none" stroke="#2c70b9" stroke-width="2px" stroke-miterlimit="10" d="M22.5,188.21c3.2-5.98,7.74-13.55,14.04-21.7c12.03-15.56,24.27-25.22,29.87-29.36
							c23.84-17.6,46.96-23.36,58.21-26.04c17.96-4.28,32.22-4.67,48.51-5.11c24.18-0.65,26.9,1.97,50.3,1.02
							c16.52-0.67,30.38-1.23,47.74-6.38c13.04-3.87,30.45-9.04,46.21-24.51c5.88-5.78,17.41-17.38,21.19-35.23
							c2.35-11.12,1.15-22.04,0.77-25.28c-0.76-6.46-2.13-11.79-3.32-15.61" style="animation-duration: 7s; animation-delay: 100ms;"></path>
						<path class="appear-animation animated customLines1anim appear-animation-visible" data-appear-animation="customLines1anim" data-appear-animation-delay="100" data-appear-animation-duration="7s" fill="none" stroke="#2c70b9" stroke-width="2px" stroke-miterlimit="10" d="M352.37,0c1.24,3.21,2.7,7.55,3.83,12.8c0.7,3.25,2.36,11.94,1.79,21.7c-1.06,18.12-9.35,31.68-11.74,35.49
							c-12.13,19.34-29.52,27.67-42.64,33.96c-21.37,10.24-40.68,12.11-51.06,13.02c-2.84,0.25-9.93,0.34-24,0.51
							c-36.73,0.45-40.07,0.2-51.57,0.51c-28.23,0.75-42.35,1.13-55.15,4.34c-23.5,5.9-39.82,16.37-49.53,22.72
							c-26.76,17.49-41.55,37.15-45.19,42.13c-5.31,7.27-9.15,13.81-11.74,18.64" style="animation-duration: 7s; animation-delay: 100ms;"></path>
						<path class="appear-animation animated customLines1anim appear-animation-visible" data-appear-animation="customLines1anim" data-appear-animation-delay="100" data-appear-animation-duration="7s" fill="none" stroke="#2c70b9" stroke-width="2px" stroke-miterlimit="10" d="M8.2,222.93c3.14-5.55,7.49-12.63,13.28-20.43c11.99-16.16,23.54-26.53,27.06-29.62
							c20.8-18.21,41.61-27.43,51.83-31.4c25.63-9.96,46.86-11.12,72.51-12.51c21.02-1.14,19.99,0.76,52.6,0
							c30.76-0.71,46.14-1.07,62.81-5.11c15.54-3.76,35.26-8.54,54.38-24.77c7.61-6.46,23.87-20.64,30.13-44.43
							c3.83-14.58,2.61-27.82,1.53-34.72c-1.31-8.35-3.62-15.13-5.62-19.95" style="animation-duration: 7s; animation-delay: 100ms;"></path>
						<path class="appear-animation animated customLines1anim appear-animation-visible" data-appear-animation="customLines1anim" data-appear-animation-delay="100" data-appear-animation-duration="7s" fill="none" stroke="#2c70b9" stroke-width="2px" stroke-miterlimit="10" d="M385.31,1.06c1.82,3.73,4.22,9.49,5.62,16.85c0.54,2.85,1.02,6.39,1.28,16.6c0.13,5.3,0.39,15.38,0,20.68
							c-1.74,23.68-23.11,43.56-27.06,47.23c-12.21,11.35-23.97,16.37-36.77,21.7c-30.51,12.7-57.92,14.15-78.64,15.06
							c-14.15,0.63-11.1-0.45-42.64-0.26c-30.2,0.19-45.31,0.28-56.68,1.79c-35.47,4.69-61.45,17.73-70.72,22.72
							c-26.73,14.38-43.36,31.12-48.51,36.51c-14.02,14.66-23.24,29.09-29.11,39.83" style="animation-duration: 7s; animation-delay: 100ms;"></path>
					</svg>
