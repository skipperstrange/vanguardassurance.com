<div class="col-sm-6 mb-5-5">
    <div class="counter text-center text-sm-start">
        <strong class="text-color-primary text-13 line-height-5" data-to="48" data-append="+" data-plugin-options="{'speed': 5200}">0</strong>
        <label class="font-weight-semibold text-5">Years In Business</label>
    </div>
</div>
<div class="col-sm-6 mb-5-5">
    <div class="counter text-center text-sm-start">
        <strong class="text-color-primary text-13 line-height-5" data-to="400" data-append="K+" data-plugin-options="{'speed': 5300}">2300</strong>
        <label class="font-weight-semibold text-5">Happy Customers</label>
    </div>
</div>
<div class="col-sm-6 mb-4 mb-sm-0">
    <div class="counter text-center text-sm-start">
        <strong class="text-color-primary text-13 line-height-5" data-to="700" data-append="+" data-plugin-options="{'speed': 5100}"></strong></strong>
        <label class="font-weight-semibold text-5">Available Agents</label>
    </div>
</div>
<div class="col-sm-6">
    <div class="counter text-center text-sm-start">
        <strong class="text-color-primary text-13 line-height-5" data-to="15" data-append="+" data-plugin-options="{'speed': 5000}">10</strong>
        <label class="font-weight-semibold text-5">Branches</label>
    </div>
</div>