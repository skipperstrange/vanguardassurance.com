<?php

$query = $_POST['query'];
$headerTitle = "<h1>Search: $query</h1>";
$headerDescription = "Loking for: $query";
$pageTitle = 'Search';
//$headerBackground = IMAGES_URL.'mobile-news-1.jpg' ;