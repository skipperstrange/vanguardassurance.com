
<?php
$headerTitle = '<h1>Articles</h1>';
$headerDescription = 'Get more information on what we\'ve been up to.';
$pageTitle = 'News';
$headerBackground = IMAGES_URL.'mobile-news-1.jpg' ;