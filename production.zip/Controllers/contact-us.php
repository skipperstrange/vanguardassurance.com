<?php
include_once STATIC_DATA.'branches.php';
$pageTitle ="Contact us";
$headerBackground = IMAGES_URL.'info-bg.jpg';
$headerTitle = '<h1>Looking for <strong>us</strong></h1>';
