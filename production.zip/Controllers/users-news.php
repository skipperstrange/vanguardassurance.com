<?php

$headerTitle = '<h1 id="user_header">Author Articles</h1>';
$headerDescription = 'Browse our article categories.';
$pageTitle = 'Author\'s Article';
$headerBackground = IMAGES_URL.'archive.jpg' ;

$user_id = $_GET['id'];
