<?php

$pageTitle = "Welcome To Vanguard Assurance";

include STATIC_DATA.'products.php'; 
$products = $data['products']['personal_lines'];

include STATIC_DATA.'affiliates.php';
$affiliates =$data['affiliates'];
