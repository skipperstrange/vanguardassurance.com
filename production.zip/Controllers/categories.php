<?php

$headerTitle = '<h1 id="cat_header">Article Categories</h1>';
$headerDescription = 'Browse our article categories.';
$pageTitle = 'Article Categories';
$headerBackground = IMAGES_URL.'archive.jpg' ;

$cat_id = $_GET['id'];
