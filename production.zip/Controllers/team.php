<?php

include_once STATIC_DATA.'board.php';
$headerTitle = '<h1>Meet <strong>Our Team</strong></h1>';
$pageTitle = 'Our Team';

$headerDescription = "Meet <strong>Our Team</strong>";
$headerBackground = IMAGES_URL."boardroom.jpg";