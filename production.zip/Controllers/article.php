<?php

$id = $_GET['id'];
$pageTitle = "Article";